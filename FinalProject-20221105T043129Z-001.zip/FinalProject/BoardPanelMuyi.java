public class BoardPanelMuyi {
    
}
